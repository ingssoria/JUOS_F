export class Post {

  constructor(public id, public title: string, public description: string) {

  }

}
