# Angular Rest 

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.3.1.
